<?php
session_start();
$user =  $_SESSION['username'];
include "koneksinya.php";
$id = $_GET['id'];
$sql = mysqli_query($conn, "SELECT * from gambar WHERE id = '$id'");
$data = mysqli_fetch_array($sql);
echo "<img src='".$data['foto']."' width='200' weight='200'>";
 ?>
 <br>
 <form action="" method="post" enctype="multipart/form-data">
   <input type="submit" name="hapus" value="Hapus">
   <br>
   Upload<input type="file" name="fotonya">
   <br>
   <input type="submit" name="edit" value="Edit">


 </form>

<?php
include 'koneksinya.php';
if (isset($_POST['hapus'])) {
  $sql = mysqli_query($conn, "DELETE FROM `gambar` WHERE id = '$id'");
  $conn->query($sql) === TRUE;
      header("Location:3.php");
}
if (isset($_POST['edit'])) {
  $file = 'ASISTEN/';
  $path = $file.basename($_FILES['fotonya']['name']);
  $sql = mysqli_query($conn, "UPDATE `gambar` SET `foto`='$path' WHERE id = '$id'");
  $conn->query($sql) === TRUE;
header("Location:3.php");
}

 ?>
