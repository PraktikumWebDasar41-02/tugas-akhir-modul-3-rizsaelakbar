<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="1.php" method="post">
      <input type="text" name="username" placeholder="Username" required>
      <br>
      <input type="password" name="password" placeholder="Password" required>
      <br>
      <input type="submit" name="submit" value="MASUK">
      <br><br>
      Belum Memiliki Akun?
      <a href="2.php">Daftar</a>

    </form>
  </body>
</html>

<?php
session_start();
include 'koneksinya.php';
if (isset($_POST['submit'])) {
$username = $_POST['username'];
$password = md5($_POST['password']);

$data = mysqli_query($conn, "SELECT * FROM akun WHERE username = '$username' AND password = '$password'");
$cek = mysqli_num_rows($data);

if($cek > 0){
  $_SESSION['username'] = $username;
  header("Location:3.php");
}
else {
  echo "<script>
alert('Login Gagal');
  </script>";
}
}

 ?>
